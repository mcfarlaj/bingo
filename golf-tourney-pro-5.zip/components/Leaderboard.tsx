import React from 'react';
import { Competition, LeaderboardEntry } from '../types';
import { Card } from './common/Card';
import { generateLeaderboard } from '../services/scoringService';

interface LeaderboardProps {
  competition: Competition;
}

const DefaultAvatar: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="currentColor" viewBox="0 0 24 24"><path d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
);

const FireIcon: React.FC<{ title: string }> = ({ title }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-orange-500" viewBox="0 0 20 20" fill="currentColor">
        <title>{title}</title>
        <path fillRule="evenodd" d="M12.316 3.051a1 1 0 01.633 1.265l-4 12a1 1 0 11-1.898-.632l4-12a1 1 0 011.265-.633zM10 4a1 1 0 01.707.293l3 3a1 1 0 01-1.414 1.414L10 6.414 7.707 8.707a1 1 0 01-1.414-1.414l3-3A1 1 0 0110 4z" clipRule="evenodd" />
    </svg>
);

const TurtleIcon: React.FC<{ title: string }> = ({ title }) => (
     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-500" viewBox="0 0 20 20" fill="currentColor">
        <title>{title}</title>
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 9a1 1 0 000 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
    </svg>
);

const TrophyIcon: React.FC<{ title: string }> = ({ title }) => (
     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-500" viewBox="0 0 20 20" fill="currentColor">
        <title>{title}</title>
        <path d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 001.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z" />
        <path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z" />
    </svg>
);

const PinIcon: React.FC<{ title: string }> = ({ title }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
        <title>{title}</title>
        <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 20l-4.95-5.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
    </svg>
);


export const Leaderboard: React.FC<LeaderboardProps> = ({ competition }) => {
  const leaderboardData = generateLeaderboard(competition);
  const totalRounds = Math.max(1, competition.numberOfRounds);

  return (
    <Card title={`${competition.name} - Leaderboard`} className="w-full">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rank</th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Player</th>
              <th scope="col" className="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">HCP</th>
              {Array.from({ length: totalRounds }, (_, i) => (
                <th key={i} scope="col" className="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">R{i + 1}</th>
              ))}
              <th scope="col" className="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {leaderboardData.length > 0 ? leaderboardData.map((entry: LeaderboardEntry, idx: number) => (
              <tr key={entry.player.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                <td className="px-3 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">{entry.rank}</td>
                <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-800">
                    <div className="flex items-center gap-3">
                        {entry.player.photo ? (
                            <img src={entry.player.photo} alt={entry.player.name} className="h-10 w-10 rounded-full object-cover" />
                        ) : (
                            <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                                <DefaultAvatar className="h-6 w-6 text-gray-400" />
                            </div>
                        )}
                        <div>
                            <div className="font-semibold text-gray-900">{entry.player.name}</div>
                            {entry.player.nickname && <div className="text-xs text-gray-500">{entry.player.nickname}</div>}
                        </div>
                        <div className="flex items-center gap-1 ml-auto">
                            {entry.isHighestRoundScorer && <FireIcon title="Best score in last round" />}
                            {entry.isLowestRoundScorer && <TurtleIcon title="Worst score in last round" />}
                            {entry.isLongestDriveWinner && <TrophyIcon title="Longest Drive Winner" />}
                            {entry.isNearestThePinWinner && <PinIcon title="Nearest the Pin Winner" />}
                        </div>
                    </div>
                </td>
                 <td className="px-3 py-4 whitespace-nowrap text-sm text-gray-500 text-center">{entry.handicapIndex.toFixed(1)}</td>
                {entry.roundTotals.map((roundTotal, i) => (
                    <td key={i} className="px-3 py-4 whitespace-nowrap text-sm text-gray-500 text-center">{roundTotal}</td>
                ))}
                <td className="px-3 py-4 whitespace-nowrap text-sm font-bold text-golf-green-800 text-center">{entry.total}</td>
              </tr>
            )) : (
              <tr>
                <td colSpan={5 + totalRounds} className="text-center py-8 text-gray-500">No players added yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Card>
  );
};