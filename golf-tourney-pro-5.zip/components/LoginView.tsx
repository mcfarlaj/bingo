import React, { useState } from 'react';
import { Card } from './common/Card';
import { Button } from './common/Button';

interface LoginViewProps {
  onLogin: (password: string) => boolean;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLogin }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate network delay
    setTimeout(() => {
      const success = onLogin(password);
      if (!success) {
        setError('Incorrect password. Please try again.');
      }
      setIsLoading(false);
      setPassword('');
    }, 500);
  };

  return (
    <div className="max-w-md mx-auto mt-10">
      <Card title="Admin Login">
        <form onSubmit={handleSubmit} className="space-y-6">
          <p className="text-sm text-gray-600">
            You must enter the admin password to manage the competition.
          </p>
          <div>
            <label htmlFor="password-input" className="block text-sm font-medium text-gray-700">Password</label>
            <input
              id="password-input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 form-input"
              required
            />
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <Button type="submit" className="w-full" isLoading={isLoading}>
            {isLoading ? 'Verifying...' : 'Login'}
          </Button>
          <style>{`.form-input { display: block; width: 100%; padding: 0.5rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.375rem; } .form-input:focus { outline: none; border-color: #22c55e; box-shadow: 0 0 0 1px #22c55e; }`}</style>
        </form>
      </Card>
    </div>
  );
};
