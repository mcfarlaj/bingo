// This component is no longer in use.
// The course selection and configuration logic has been simplified and moved
// directly into the EditorView's setup wizard to create a more streamlined user experience.
