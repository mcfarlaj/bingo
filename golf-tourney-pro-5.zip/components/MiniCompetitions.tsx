import React from 'react';
import { Competition, Par3Result } from '../types';
import { Card } from './common/Card';
import { generatePar3Leaderboard } from '../services/scoringService';

interface MiniCompetitionsProps {
  competition: Competition;
}

interface Par3LeaderboardProps {
    data: Par3Result[];
    title: string;
}

const Par3LeaderboardDisplay: React.FC<Par3LeaderboardProps> = ({ data, title }) => {
    return (
        <Card title={title} className="w-full">
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rank</th>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Player</th>
                            <th scope="col" className="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Total Points</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {data.length > 0 ? data.map((entry, idx) => (
                            <tr key={entry.player.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                <td className="px-3 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">{entry.rank}</td>
                                <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-800">{entry.player.name}</td>
                                <td className="px-3 py-4 whitespace-nowrap text-sm font-bold text-golf-green-800 text-center">{entry.total}</td>
                            </tr>
                        )) : (
                            <tr>
                                <td colSpan={3} className="text-center py-8 text-gray-500">No scores recorded for par 3s yet.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </Card>
    );
};

const SideGamesResults: React.FC<{ competition: Competition }> = ({ competition }) => {
    const { players, longestDriveWinners, nearestThePinWinners, rounds } = competition;
    const hasSideGames = longestDriveWinners.length > 0 || nearestThePinWinners.length > 0;
    
    if (!hasSideGames) {
        return null;
    }

    return (
        <Card title="Side-Game Results" className="w-full">
            <div className="space-y-4">
                {rounds.map((_, roundIndex) => {
                    const ldWinnerId = longestDriveWinners[roundIndex];
                    const ntpWinnerId = nearestThePinWinners[roundIndex];
                    
                    if (!ldWinnerId && !ntpWinnerId) return null;

                    const ldWinner = ldWinnerId ? players.find(p => p.id === ldWinnerId) : null;
                    const ntpWinner = ntpWinnerId ? players.find(p => p.id === ntpWinnerId) : null;

                    return (
                        <div key={roundIndex} className="border-t border-gray-200 pt-3 first:border-t-0">
                            <h4 className="font-semibold text-gray-800">Round {roundIndex + 1}</h4>
                            <ul className="text-sm space-y-1 mt-2">
                                {ldWinnerId !== undefined && (
                                     <li className="flex justify-between items-center">
                                        <span>Longest Drive:</span>
                                        {ldWinner ? <span className="font-semibold text-golf-green-700">{ldWinner.name}</span> : <span className="text-gray-500">No winner</span>}
                                    </li>
                                )}
                                 {ntpWinnerId !== undefined && (
                                    <li className="flex justify-between items-center">
                                        <span>Nearest the Pin:</span>
                                        {ntpWinner ? <span className="font-semibold text-golf-green-700">{ntpWinner.name}</span> : <span className="text-gray-500">No winner</span>}
                                    </li>
                                )}
                            </ul>
                        </div>
                    );
                })}
            </div>
        </Card>
    );
};

export const MiniCompetitions: React.FC<MiniCompetitionsProps> = ({ competition }) => {
  const { rounds, par3CompetitionScope, par3CompetitionName, longestDriveWinners, nearestThePinWinners } = competition;
  
  const anySideGamesEnabled = longestDriveWinners.some(id => id) || nearestThePinWinners.some(id => id);
  
  if (!par3CompetitionName && !anySideGamesEnabled) {
    return null;
  }

  const overallPar3Data = (par3CompetitionName && par3CompetitionScope === 'overall' && rounds.length > 0)
    ? generatePar3Leaderboard(competition)
    : [];
    
  const perRoundPar3Data = (par3CompetitionName && par3CompetitionScope === 'per_round' && rounds.length > 0)
    ? generatePar3Leaderboard(competition, rounds.length - 1)
    : [];


  return (
    <div>
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Mini-Competitions</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {anySideGamesEnabled && <SideGamesResults competition={competition} />}

            {overallPar3Data.length > 0 && par3CompetitionName && (
                <Par3LeaderboardDisplay data={overallPar3Data} title={`${par3CompetitionName} (Overall)`} />
            )}
            
            {perRoundPar3Data.length > 0 && par3CompetitionName && (
                <Par3LeaderboardDisplay
                    data={perRoundPar3Data}
                    title={`${par3CompetitionName} - Round ${rounds.length}`}
                />
            )}
        </div>
    </div>
  );
};