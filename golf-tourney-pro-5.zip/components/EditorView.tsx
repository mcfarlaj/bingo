import React, { useState, useEffect } from 'react';
import { Competition, CompetitionFormat, Player, RoundResult, HandicapAdjustmentMethod } from '../types';
import { Card } from './common/Card';
import { Button } from './common/Button';
import { Leaderboard } from './Leaderboard';
import { MiniCompetitions } from './MiniCompetitions';
import { adjustHandicaps } from '../services/scoringService';

const SetupWizard: React.FC<{ onSetupComplete: (comp: Competition) => void }> = ({ onSetupComplete }) => {
    // Main settings
    const [name, setName] = useState('Golf Tour Championship 2024');
    const [format, setFormat] = useState<CompetitionFormat>(CompetitionFormat.STABLEFORD);
    const [numberOfRounds, setNumberOfRounds] = useState(2);
    const [handicapMethod, setHandicapMethod] = useState<HandicapAdjustmentMethod>(HandicapAdjustmentMethod.MANUAL);

    // Par 3
    const [par3CompetitionName, setPar3CompetitionName] = useState('Par 3 Competition');
    const [par3Scope, setPar3Scope] = useState<'overall' | 'per_round'>('overall');

    const handleCreateCompetition = () => {
        const newCompetition: Competition = {
            id: `comp-${Date.now()}`,
            name,
            format,
            par3CompetitionName: par3CompetitionName.trim() || null,
            par3CompetitionScope: par3Scope,
            players: [],
            rounds: [],
            numberOfRounds,
            longestDriveWinners: [],
            nearestThePinWinners: [],
            handicapAdjustmentMethod: handicapMethod,
        };
        onSetupComplete(newCompetition);
    };

    return (
        <Card title="New Competition Setup">
            <div className="space-y-6">
                {/* Main Settings */}
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="comp-name" className="block text-sm font-medium text-gray-700">Competition Name</label>
                        <input id="comp-name" type="text" value={name} onChange={e => setName(e.target.value)} className="mt-1 form-input"/>
                    </div>
                    <div>
                        <label htmlFor="comp-format" className="block text-sm font-medium text-gray-700">Format</label>
                        <select id="comp-format" value={format} onChange={e => setFormat(e.target.value as CompetitionFormat)} className="mt-1 form-input">
                            {Object.values(CompetitionFormat).map(f => <option key={f} value={f}>{f}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="num-rounds" className="block text-sm font-medium text-gray-700">Number of Rounds</label>
                        <select id="num-rounds" value={numberOfRounds} onChange={e => setNumberOfRounds(parseInt(e.target.value, 10))} className="mt-1 form-input">
                           {[1, 2, 3, 4].map(n => <option key={n} value={n}>{n}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="hcp-method" className="block text-sm font-medium text-gray-700">Handicap Adjustment</label>
                        <select id="hcp-method" value={handicapMethod} onChange={e => setHandicapMethod(e.target.value as HandicapAdjustmentMethod)} className="mt-1 form-input">
                            {Object.values(HandicapAdjustmentMethod).map(m => <option key={m} value={m}>{m}</option>)}
                        </select>
                    </div>
                </div>

                {/* Mini Games */}
                <fieldset className="border-t border-gray-200 pt-6">
                    <legend className="text-lg font-medium text-gray-900">Mini-Games</legend>
                     <div className="mt-4 space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="par3-name" className="block text-sm font-medium text-gray-700">Par 3 Competition Name</label>
                                <input
                                    id="par3-name"
                                    type="text"
                                    value={par3CompetitionName}
                                    onChange={e => setPar3CompetitionName(e.target.value)}
                                    placeholder="e.g., King of the Shorts"
                                    className="mt-1 form-input"
                                />
                                <p className="text-xs text-gray-500 mt-1">Leave blank to disable Par 3 comp. NTP/LD are set per-round during score entry.</p>
                            </div>
                            <div>
                                <label htmlFor="par3-scope" className="block text-sm font-medium text-gray-700">Par 3 Scope</label>
                                <select
                                    id="par3-scope"
                                    value={par3Scope}
                                    onChange={e => setPar3Scope(e.target.value as 'overall' | 'per_round')}
                                    className="mt-1 form-input"
                                    disabled={!par3CompetitionName}
                                >
                                    <option value="overall">Overall (All Rounds)</option>
                                    <option value="per_round">Per Round</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </fieldset>
                
                <Button onClick={handleCreateCompetition} className="w-full">Create Competition</Button>
            </div>
             <style>{`.form-input { display: block; width: 100%; padding: 0.5rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.375rem; } .form-input:focus { outline: none; border-color: #22c55e; box-shadow: 0 0 0 1px #22c55e; }`}</style>
        </Card>
    );
};

const DefaultAvatar: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="currentColor" viewBox="0 0 24 24"><path d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
);

type NewPlayerState = Omit<Player, 'id'>;

const PlayerManager: React.FC<{ players: Player[], onPlayersChange: (players: Player[]) => void }> = ({ players, onPlayersChange }) => {
    const [newPlayer, setNewPlayer] = useState<NewPlayerState>({ name: '', nickname: '', photo: '', handicapIndex: 18.0 });

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value, type } = e.target;
        setNewPlayer(p => ({ ...p, [name]: type === 'number' ? parseFloat(value) : value }));
    };
    
    const handleHandicapChange = (playerId: string, value: string) => {
        const newHandicap = parseFloat(value);
        if (isNaN(newHandicap)) return;
        onPlayersChange(players.map(p => p.id === playerId ? { ...p, handicapIndex: newHandicap } : p));
    };

    const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setNewPlayer(p => ({ ...p, photo: reader.result as string }));
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    };

    const handleAddPlayer = (e: React.FormEvent) => {
        e.preventDefault();
        if (newPlayer.name && !isNaN(newPlayer.handicapIndex)) {
            const playerToAdd: Player = {
                id: `player-${Date.now()}`,
                name: newPlayer.name,
                nickname: newPlayer.nickname,
                photo: newPlayer.photo,
                handicapIndex: newPlayer.handicapIndex,
            };
            onPlayersChange([...players, playerToAdd]);
            setNewPlayer({ name: '', nickname: '', photo: '', handicapIndex: 18.0 });
        }
    };

    const handleDeletePlayer = (playerId: string) => {
        onPlayersChange(players.filter(p => p.id !== playerId));
    };

    return (
        <Card title="Players">
            <form onSubmit={handleAddPlayer} className="space-y-4 mb-6 pb-6 border-b border-gray-200">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="player-name" className="block text-sm font-medium text-gray-700">Full Name</label>
                        <input id="player-name" name="name" type="text" value={newPlayer.name} onChange={handleInputChange} className="mt-1 form-input" required />
                    </div>
                    <div>
                        <label htmlFor="player-nickname" className="block text-sm font-medium text-gray-700">Nickname</label>
                        <input id="player-nickname" name="nickname" type="text" value={newPlayer.nickname || ''} onChange={handleInputChange} className="mt-1 form-input" />
                    </div>
                     <div>
                        <label htmlFor="player-handicap" className="block text-sm font-medium text-gray-700">Handicap</label>
                        <input id="player-handicap" name="handicapIndex" type="number" step="0.1" value={newPlayer.handicapIndex} onChange={handleInputChange} className="mt-1 form-input" required />
                    </div>
                </div>
                <div className="flex items-end gap-4">
                     <div className="flex-shrink-0">
                         <label htmlFor="player-photo" className="block text-sm font-medium text-gray-700 mb-1">Photo</label>
                         {newPlayer.photo ? (
                            <img src={newPlayer.photo} alt="Preview" className="h-16 w-16 rounded-full object-cover" />
                        ) : (
                            <div className="h-16 w-16 rounded-full bg-gray-200 flex items-center justify-center">
                                <DefaultAvatar className="h-8 w-8 text-gray-400" />
                            </div>
                        )}
                    </div>
                    <div className="flex-grow">
                        <label htmlFor="photo-upload" className="cursor-pointer bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-golf-green-500">
                            <span>Upload</span>
                            <input id="photo-upload" name="photo-upload" type="file" className="sr-only" onChange={handlePhotoUpload} accept="image/*" />
                        </label>
                    </div>
                </div>
                <Button type="submit" className="w-full">Add Player</Button>
            </form>
            <h4 className="text-md font-semibold text-gray-800 mb-2">{players.length > 0 ? 'Current Players' : 'No players added yet.'}</h4>
            <ul className="divide-y divide-gray-200">
                {players.map(p => (
                    <li key={p.id} className="py-3 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-3 flex-grow">
                            {p.photo ? <img src={p.photo} alt={p.name} className="h-10 w-10 rounded-full object-cover" /> : <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center"><DefaultAvatar className="h-6 w-6 text-gray-400" /></div>}
                            <div className="flex-grow">
                                <div className="font-medium text-gray-900">{p.name}</div>
                                {p.nickname && <div className="text-sm text-gray-500">{p.nickname}</div>}
                            </div>
                        </div>
                        <div className="w-24">
                             <input type="number" step="0.1" value={p.handicapIndex} onChange={e => handleHandicapChange(p.id, e.target.value)} className="w-full text-center form-input text-sm p-1" aria-label={`Handicap for ${p.name}`} />
                        </div>
                        <Button onClick={() => handleDeletePlayer(p.id)} variant="danger" size="sm">Remove</Button>
                    </li>
                ))}
            </ul>
            <style>{`.form-input { display: block; width: 100%; padding: 0.5rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.375rem; }`}</style>
        </Card>
    );
};

const ScoreEntry: React.FC<{ competition: Competition, onRoundComplete: (results: RoundResult[], ldWinnerId: string | null, ntpWinnerId: string | null) => void }> = ({ competition, onRoundComplete }) => {
    const roundNumber = competition.rounds.length + 1;
    const scoreLabel = competition.format === CompetitionFormat.STABLEFORD ? "Points" : "Net Strokes";

    const initialScores = competition.players.map(p => ({
        playerId: p.id,
        roundNumber,
        roundScore: null,
        par3Score: null,
    }));
    const [roundResults, setRoundResults] = useState<RoundResult[]>(initialScores);
    const [ldWinner, setLdWinner] = useState<string>('');
    const [ntpWinner, setNtpWinner] = useState<string>('');
    
    const handleScoreChange = (playerId: string, scoreType: 'roundScore' | 'par3Score', value: string) => {
        const score = value === '' ? null : parseInt(value, 10);
        // Allow negative scores for stroke play but not for points
        if (value !== '' && isNaN(score)) return;
        if (scoreType !== 'roundScore' && score !== null && score < 0) return;

        setRoundResults(prevResults => prevResults.map(res => 
            res.playerId === playerId ? { ...res, [scoreType]: score } : res
        ));
    };
    
    return (
        <Card title={`Enter Scores: Round ${roundNumber}`}>
             <div className="p-4 bg-gray-50 rounded-lg mb-6 border border-gray-200">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Round Awards</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     <div>
                        <label className="block text-sm font-medium text-gray-700">Longest Drive Winner</label>
                        <select value={ldWinner} onChange={e => setLdWinner(e.target.value)} className="mt-1 block w-full select-input">
                            <option value="">-- Select Winner --</option>
                            {competition.players.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700">Nearest the Pin Winner</label>
                        <select value={ntpWinner} onChange={e => setNtpWinner(e.target.value)} className="mt-1 block w-full select-input">
                            <option value="">-- Select Winner --</option>
                            {competition.players.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                    </div>
                </div>
                 <style>{`.select-input { display: block; width: 100%; padding: 0.5rem 0.75rem; border-radius: 0.375rem; border: 1px solid #d1d5db; } .select-input:focus { outline: none; border-color: #22c55e; box-shadow: 0 0 0 1px #22c55e; }`}</style>
            </div>
            <div className="space-y-4">
                {competition.players.map(player => {
                    const result = roundResults.find(r => r.playerId === player.id);
                    return (
                        <div key={player.id} className="p-4 border rounded-lg grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                            <div className="font-semibold text-gray-800">{player.name}</div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Round Score ({scoreLabel})</label>
                                <input
                                    type="number"
                                    aria-label={`Round score for ${player.name}`}
                                    className="w-full text-center border border-gray-300 rounded-md p-2 mt-1"
                                    value={result?.roundScore ?? ''}
                                    onChange={e => handleScoreChange(player.id, 'roundScore', e.target.value)}
                                />
                            </div>
                             {competition.par3CompetitionName && (
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">{competition.par3CompetitionName} (Points)</label>
                                    <input
                                        type="number"
                                        min="0"
                                        aria-label={`Par 3 score for ${player.name}`}
                                        className="w-full text-center border border-gray-300 rounded-md p-2 mt-1"
                                        value={result?.par3Score ?? ''}
                                        onChange={e => handleScoreChange(player.id, 'par3Score', e.target.value)}
                                    />
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
            <Button className="mt-6 w-full" onClick={() => onRoundComplete(roundResults, ldWinner || null, ntpWinner || null)}>Finalize Round {roundNumber}</Button>
        </Card>
    );
};

interface EditorViewProps {
    competition: Competition | null;
    setCompetition: React.Dispatch<React.SetStateAction<Competition | null>>;
}

export const EditorView: React.FC<EditorViewProps> = ({ competition, setCompetition }) => {
    const [isEnteringScores, setIsEnteringScores] = useState(false);

    if (!competition) {
        return <SetupWizard onSetupComplete={setCompetition} />;
    }

    const handlePlayersChange = (players: Player[]) => {
        setCompetition(c => c ? { ...c, players } : null);
    };

    const handleStartNewRound = () => {
       setIsEnteringScores(true);
    };
    
    const handleRoundComplete = (results: RoundResult[], ldWinnerId: string | null, ntpWinnerId: string | null) => {
        setCompetition(c => {
            if (!c) return null;
            const updatedPlayers = adjustHandicaps(c, results);
            return {
                ...c,
                players: updatedPlayers,
                rounds: [...c.rounds, results],
                longestDriveWinners: [...c.longestDriveWinners, ldWinnerId],
                nearestThePinWinners: [...c.nearestThePinWinners, ntpWinnerId],
            };
        });
        setIsEnteringScores(false);
    };

    const roundInProgress = isEnteringScores;
    const canStartNewRound = competition.players.length > 0 && !roundInProgress && competition.rounds.length < competition.numberOfRounds;
    const isCompetitionFinished = competition.rounds.length === competition.numberOfRounds && !roundInProgress;

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">{competition.name}</h2>
            <Leaderboard competition={competition} />
            <MiniCompetitions competition={competition} />
            
            {roundInProgress ? (
                <ScoreEntry competition={competition} onRoundComplete={handleRoundComplete} />
            ) : (
                <div className="grid md:grid-cols-2 gap-6">
                    <PlayerManager players={competition.players} onPlayersChange={handlePlayersChange} />
                    <div className="space-y-6">
                        <Card title="Competition Control">
                            <Button onClick={handleStartNewRound} disabled={!canStartNewRound}>
                                {isCompetitionFinished ? 'Competition Finished' : 
                                 competition.rounds.length === 0 ? `Start First Round` : `Start Round ${competition.rounds.length + 1}`
                                }
                            </Button>
                             {isCompetitionFinished && (
                                <p className="mt-4 text-center font-semibold text-golf-green-700">All {competition.numberOfRounds} rounds are complete!</p>
                             )}
                        </Card>
                    </div>
                </div>
            )}
        </div>
    );
};