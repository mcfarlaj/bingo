import React, { useState } from 'react';
import { Competition, View } from './types';
import { EditorView } from './components/EditorView';
import { Leaderboard } from './components/Leaderboard';
import { Card } from './components/common/Card';
import { MiniCompetitions } from './components/MiniCompetitions';
import { LoginView } from './components/LoginView';

const Header: React.FC<{ view: View, setView: (view: View) => void, isAuthenticated: boolean, onLogout: () => void }> = ({ view, setView, isAuthenticated, onLogout }) => {
  const inactiveClass = "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700";
  const activeClass = "border-golf-green-500 text-golf-green-600";
  
  return (
    <div className="bg-white shadow-sm mb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-golf-green-700" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM5.555 12.222a.5.5 0 01.354.146l1.415 1.414a.5.5 0 01-.708.708l-1.414-1.414a.5.5 0 01.146-.862zM12.5 6a.5.5 0 01.5.5v1a.5.5 0 01-1 0v-1a.5.5 0 01.5-.5zM10 4a.5.5 0 01.5.5v1a.5.5 0 01-1 0v-1A.5.5 0 0110 4zM6.5 8a.5.5 0 01.5.5v1a.5.5 0 01-1 0v-1a.5.5 0 01.5-.5zM15 10a.5.5 0 01.5.5v1a.5.5 0 01-1 0v-1a.5.5 0 01.5-.5zm-5-3a.5.5 0 01.5.5v1a.5.5 0 01-1 0v-1a.5.5 0 01.5-.5zM7.5 12a.5.5 0 01.5.5v1a.5.5 0 01-1 0v-1a.5.5 0 01.5-.5z" />
            </svg>
            <h1 className="text-2xl font-bold text-gray-800">Golf Tourney Pro</h1>
          </div>
          <div className="flex items-center space-x-8">
             <button onClick={() => setView('player')} className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${view === 'player' ? activeClass : inactiveClass}`}>Player View</button>
             <button onClick={() => setView('editor')} className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${view === 'editor' ? activeClass : inactiveClass}`}>Admin View</button>
             {isAuthenticated && (
                <button onClick={onLogout} className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:text-red-600 hover:border-red-300">
                    Logout
                </button>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};


const PlayerView: React.FC<{ competition: Competition | null }> = ({ competition }) => {
    if (!competition) {
        return (
            <Card className="text-center">
                <h3 className="text-lg font-medium text-gray-900">No Competition Active</h3>
                <p className="mt-1 text-sm text-gray-500">The administrator has not set up a competition yet. Please check back later.</p>
            </Card>
        );
    }
    return (
        <div className="space-y-6">
            <Leaderboard competition={competition} />
            <MiniCompetitions competition={competition} />
        </div>
    );
};


function App() {
  const [view, setView] = useState<View>('player');
  const [competition, setCompetition] = useState<Competition | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = (password: string): boolean => {
      const ADMIN_PASSWORD = 'golfpro'; // This is not secure for a real application.
      if (password === ADMIN_PASSWORD) {
          setIsAuthenticated(true);
          return true;
      }
      return false;
  };

  const handleLogout = () => {
      setIsAuthenticated(false);
      setView('player'); // Go back to player view on logout
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans">
      <Header view={view} setView={setView} isAuthenticated={isAuthenticated} onLogout={handleLogout} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
        {view === 'player' && <PlayerView competition={competition} />}
        {view === 'editor' && isAuthenticated && (
            <EditorView competition={competition} setCompetition={setCompetition} />
        )}
        {view === 'editor' && !isAuthenticated && (
            <LoginView onLogin={handleLogin} />
        )}
      </main>
    </div>
  );
}

export default App;
