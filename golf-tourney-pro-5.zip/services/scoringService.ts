import { Competition, Player, RoundResult, CompetitionFormat, LeaderboardEntry, Par3Result, HandicapAdjustmentMethod } from '../types';

// --- Handicap Adjustments ---
export const adjustHandicaps = (competition: Competition, lastRoundResults: RoundResult[]): Player[] => {
    const { players, handicapAdjustmentMethod, format } = competition;
    if (handicapAdjustmentMethod === HandicapAdjustmentMethod.MANUAL) {
        return players; // No changes
    }

    const updatedPlayers = [...players];
    const finishedPlayersResults = lastRoundResults.filter(r => typeof r.roundScore === 'number');
    if (finishedPlayersResults.length === 0) return players;

    // Method 1: Simple cut for the winner
    if (handicapAdjustmentMethod === HandicapAdjustmentMethod.SIMPLE) {
        let bestScore: number;
        if (format === CompetitionFormat.STABLEFORD) {
            bestScore = Math.max(...finishedPlayersResults.map(r => r.roundScore!));
        } else {
            bestScore = Math.min(...finishedPlayersResults.map(r => r.roundScore!));
        }
        const winners = finishedPlayersResults.filter(r => r.roundScore === bestScore);
        
        winners.forEach(winner => {
            const playerIndex = updatedPlayers.findIndex(p => p.id === winner.playerId);
            if (playerIndex > -1) {
                const oldHandicap = updatedPlayers[playerIndex].handicapIndex;
                updatedPlayers[playerIndex].handicapIndex = Math.round((oldHandicap * 0.9) * 10) / 10;
            }
        });
    }

    // Method 2: Daily Performance Adjustment
    if (handicapAdjustmentMethod === HandicapAdjustmentMethod.DAILY_PERFORMANCE) {
        const scores = finishedPlayersResults.map(r => r.roundScore!);
        const averageScore = scores.reduce((sum, score) => sum + score, 0) / scores.length;

        finishedPlayersResults.forEach(result => {
            const playerIndex = updatedPlayers.findIndex(p => p.id === result.playerId);
            if (playerIndex > -1) {
                const player = updatedPlayers[playerIndex];
                const playerScore = result.roundScore!;
                
                let performanceFactor = (averageScore - playerScore);
                // For stroke play, lower is better (so positive factor is good).
                // For stableford, higher is better (so positive factor is good).
                if(format === CompetitionFormat.STROKE_PLAY) {
                    performanceFactor = -performanceFactor;
                }

                const adjustment = (performanceFactor * player.handicapIndex) / 100;
                const newHandicap = player.handicapIndex + adjustment;
                
                updatedPlayers[playerIndex].handicapIndex = Math.round(newHandicap * 10) / 10;
            }
        });
    }
    
    return updatedPlayers;
};


// --- Leaderboard Generation ---
export const generateLeaderboard = (competition: Competition): LeaderboardEntry[] => {
  if (!competition.players.length || competition.numberOfRounds === 0) return [];

  const playerTotals: { [playerId: string]: { total: number; rounds: (number | string)[] } } = {};
  
  competition.players.forEach(p => {
    playerTotals[p.id] = { total: 0, rounds: Array(competition.rounds.length).fill('-') };
  });

  // Achievement Tracking for the last round
  let highestScorers: string[] = [];
  let lowestScorers: string[] = [];
  let longestDriveWinnerId: string | null = null;
  let nearestThePinWinnerId: string | null = null;
  
  competition.rounds.forEach((round, roundIndex) => {
    // Track daily achievements for the latest completed round
    if (roundIndex === competition.rounds.length - 1) {
        const finishedPlayersResults = round.filter(r => typeof r.roundScore === 'number');

        if (finishedPlayersResults.length > 0) {
            const scores = finishedPlayersResults.map(r => r.roundScore!);
            let bestScore: number;
            let worstScore: number;

            if (competition.format === CompetitionFormat.STABLEFORD) {
                bestScore = Math.max(...scores);
                worstScore = Math.min(...scores);
            } else { // Stroke Play
                bestScore = Math.min(...scores);
                worstScore = Math.max(...scores);
            }

            highestScorers = finishedPlayersResults.filter(r => r.roundScore === bestScore).map(r => r.playerId);
            lowestScorers = finishedPlayersResults.filter(r => r.roundScore === worstScore).map(r => r.playerId);
        }
        
        longestDriveWinnerId = competition.longestDriveWinners?.[roundIndex] ?? null;
        nearestThePinWinnerId = competition.nearestThePinWinners?.[roundIndex] ?? null;
    }

    round.forEach(res => {
        if (res.roundScore !== null) {
            playerTotals[res.playerId].total += res.roundScore;
            playerTotals[res.playerId].rounds[roundIndex] = res.roundScore;
        }
    });
  });

  const sortedPlayerIds = Object.keys(playerTotals).sort((a, b) => {
    const totalA = playerTotals[a].total;
    const totalB = playerTotals[b].total;
    // For stroke play, a lower score is better. For stableford, a higher score is better.
    return competition.format === CompetitionFormat.STABLEFORD ? totalB - totalA : totalA - totalB;
  });

  let rank = 1;
  return sortedPlayerIds.map((playerId, index) => {
    const player = competition.players.find(p => p.id === playerId)!;
    const prevPlayerId = index > 0 ? sortedPlayerIds[index - 1] : null;
    
    if (prevPlayerId && playerTotals[playerId].total !== playerTotals[prevPlayerId].total) {
      rank = index + 1;
    }
    
    const hasScores = playerTotals[playerId].rounds.some(r => r !== '-');

    return {
      rank: hasScores ? rank : 'T',
      player,
      total: playerTotals[playerId].total,
      roundTotals: playerTotals[playerId].rounds,
      handicapIndex: player.handicapIndex,
      isHighestRoundScorer: highestScorers.includes(playerId),
      isLowestRoundScorer: lowestScorers.includes(playerId),
      isLongestDriveWinner: playerId === longestDriveWinnerId,
      isNearestThePinWinner: playerId === nearestThePinWinnerId,
    };
  });
};


// --- Mini-Competition Calculations ---

export const generatePar3Leaderboard = (competition: Competition, specificRoundIndex?: number): Par3Result[] => {
    const { players, rounds, par3CompetitionScope, par3CompetitionName } = competition;

    if (!players.length || !par3CompetitionName || rounds.length === 0) return [];

    let roundsToProcess: RoundResult[][] = [];

    if (typeof specificRoundIndex === 'number') {
        if (rounds[specificRoundIndex]) roundsToProcess.push(rounds[specificRoundIndex]);
    } else if (par3CompetitionScope === 'per_round') {
        const lastRound = rounds[rounds.length - 1];
        if (lastRound) roundsToProcess.push(lastRound);
    } else { // overall
        roundsToProcess = [...rounds];
    }
    
    if (roundsToProcess.length === 0) return [];

    const playerTotals: { [playerId: string]: number } = {};
    players.forEach(p => { playerTotals[p.id] = 0; });

    roundsToProcess.forEach(round => {
        round.forEach(result => {
            if (result.par3Score !== null) {
                 playerTotals[result.playerId] += result.par3Score;
            }
        });
    });

    const sortedPlayerIds = Object.keys(playerTotals).sort((a, b) => playerTotals[b] - playerTotals[a]);

    let rank = 1;
    return sortedPlayerIds.map((playerId, index) => {
        const player = players.find(p => p.id === playerId)!;
        const prevPlayerId = index > 0 ? sortedPlayerIds[index - 1] : null;
        if (prevPlayerId && playerTotals[playerId] !== playerTotals[prevPlayerId]) {
            rank = index + 1;
        }
        return {
            rank: playerTotals[playerId] > 0 ? rank : 'T',
            player,
            total: playerTotals[playerId],
        };
    });
};