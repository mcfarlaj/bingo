// This service is no longer used. Course data is now mocked from a simulated USGA source.
