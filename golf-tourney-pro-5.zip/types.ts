export enum CompetitionFormat {
  STROKE_PLAY = 'Stroke Play',
  STABLEFORD = 'Stableford',
}

export enum HandicapAdjustmentMethod {
  MANUAL = 'Manual',
  SIMPLE = 'Simple Winner Cut (10%)',
  DAILY_PERFORMANCE = 'Daily Performance Adjustment',
}

export interface Player {
  id: string;
  name: string;
  nickname?: string;
  photo?: string; // base64 encoded image
  handicapIndex: number;
}

export interface RoundResult {
  playerId: string;
  roundNumber: number;
  roundScore: number | null; // Manually entered net score or points
  par3Score: number | null; // Manually entered par 3 points
}

export interface Competition {
  id: string;
  name: string;
  format: CompetitionFormat;
  par3CompetitionName: string | null; // A custom name for the par 3 comp. If null/empty, it's disabled.
  par3CompetitionScope: 'overall' | 'per_round';
  players: Player[];
  rounds: RoundResult[][]; // Array of rounds, where each round is an array of player results
  numberOfRounds: number;
  longestDriveWinners: Array<string | null>; // Index corresponds to round number - 1
  nearestThePinWinners: Array<string | null>; // Index corresponds to round number - 1
  handicapAdjustmentMethod: HandicapAdjustmentMethod;
}

export type View = 'editor' | 'player';

export interface LeaderboardEntry {
  rank: number | string;
  player: Player;
  total: number;
  roundTotals: (number | string)[];
  handicapIndex: number;
  isHighestRoundScorer?: boolean;
  isLowestRoundScorer?: boolean;
  isLongestDriveWinner?: boolean;
  isNearestThePinWinner?: boolean;
}

// Mini-Competition Result Types
export interface Par3Result {
  rank: number | string;
  player: Player;
  total: number; // Manually entered and aggregated points
}